@echo off
cd /d "%~dp0"
echo Starting the site... open http://localhost:4200 in the browser
call npm start
pause
